package com.vijays.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vijays.springboot.dao.EmployeeDAO;
import com.vijays.springboot.entity.Employee;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
  
	@Autowired
	private EmployeeDAO EmployeeDAO;
	@Override
	public Employee getEmployeeById(int EmployeeId) {
		Employee obj = EmployeeDAO.getEmployeeById(EmployeeId);
		return obj;
	}	
	@Override
	public List<Employee> getAllEmployees(){
		return EmployeeDAO.getAllEmployees();
	}
	@Override
	public synchronized boolean addEmployee(Employee Employee){
      /* if (EmployeeDAO.EmployeeExists(Employee.getTitle(), Employee.getCategory())) {
    	   return false;
       } else {*/
    	   EmployeeDAO.addEmployee(Employee);
    	   return true;
      /* }*/
	}
	@Override
	public void updateEmployee(Employee Employee) {
		EmployeeDAO.updateEmployee(Employee);
	}
	@Override
	public void deleteEmployee(int EmployeeId) {
		EmployeeDAO.deleteEmployee(EmployeeId);
	}
	}

