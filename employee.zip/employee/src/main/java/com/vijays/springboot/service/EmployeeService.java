package com.vijays.springboot.service;

import java.util.List;

import com.vijays.springboot.entity.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();
    Employee getEmployeeById(int EmployeeId);
    boolean addEmployee(Employee Employee);
    void updateEmployee(Employee Employee);
    void deleteEmployee(int EmployeeId);

}