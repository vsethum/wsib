package com.vijays.springboot.dao;

import java.util.List;

import com.vijays.springboot.entity.Employee;

public interface EmployeeDAO {
	
	List<Employee> getAllEmployees();
	Employee getEmployeeById(int id);
    void addEmployee(Employee employee);
	void updateEmployee(Employee employee);
	void deleteEmployee(int employeeId);

}
