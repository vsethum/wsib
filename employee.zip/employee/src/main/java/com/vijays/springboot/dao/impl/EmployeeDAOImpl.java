package com.vijays.springboot.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vijays.springboot.dao.EmployeeDAO;
import com.vijays.springboot.entity.Employee;

@Transactional
@Repository

public class EmployeeDAOImpl implements EmployeeDAO {
	
	@PersistenceContext	
	private EntityManager entityManager;	
	
	@Override
	public Employee getEmployeeById(int EmployeeId) {
		return entityManager.find(Employee.class, EmployeeId);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAllEmployees() {
		String hql = "FROM Employee ";
		return (List<Employee>) entityManager.createQuery(hql).getResultList();
	}	
	
	@Override
	public void addEmployee(Employee Employee) {
		entityManager.persist(Employee);
	}
	
	@Override
	public void updateEmployee(Employee employee) {
		/*Employee newEmployee = getEmployeeById(employee.getEmployeeId());
		newEmployee.setTitle(employee.getTitle());
		newEmployee.setFirstName(employee.getFirstName());
		newEmployee.setLastName(employee.getLastName());
		newEmployee.setDepartment(employee.getDepartment());
		newEmployee.setHiredDate(employee.getHiredDate());
		newEmployee.setSupervisorEmployeeId(employee.getSupervisorEmployeeId());*/
		entityManager.merge(employee);
	}
	
	@Override
	public void deleteEmployee(int EmployeeId) {
		entityManager.remove(getEmployeeById(EmployeeId));
	}	
	
}
